﻿
namespace Panel
{
    public class PredefinePanel : BasePanel
    {
    }
}

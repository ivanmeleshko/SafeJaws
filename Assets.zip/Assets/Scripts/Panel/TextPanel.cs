﻿

namespace Panel
{
    public class TextPanel : BasePanel
    {
    }
}

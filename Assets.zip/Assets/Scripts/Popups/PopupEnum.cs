﻿
namespace Popups
{
    public enum PopupEnum
    {
        SimplePoup
    }
}

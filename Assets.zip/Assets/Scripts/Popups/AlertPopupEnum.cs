﻿

namespace Popups
{
    public enum AlertPopupEnum
    {
        NoInternetConnection,
        WarningMessage,
        InviteType,
        Message
    }
}

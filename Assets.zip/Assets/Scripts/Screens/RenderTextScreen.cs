﻿using System;
using System.Collections;
using Model;
using UnityEngine;

namespace Screens
{
    public class RenderTextScreen : MonoBehaviour
    {
        [SerializeField] private UnityEngine.TextMesh _textMesh;
        [SerializeField] private RenderTexture _liveRenderTexture;
        [SerializeField] private Camera _camera;
        [SerializeField] private Renderer _render;
        private Action<Texture2D> _onCompleteAction;

        public void OnGetTexture(string text, FontModel fontModel, Action<Texture2D> onCompleteAction)
        {
            _textMesh.font = fontModel.Font;
            _textMesh.text = text;
            _textMesh.fontSize = fontModel.FontSize;
            _textMesh.color = fontModel.FontColor.Color;
           _onCompleteAction = onCompleteAction;
            _render.material = fontModel.Font.material;
            _render.material.SetFloat("_Metallic/_Smoothness", fontModel.FontColor.MetalicSmoothess);
            StartCoroutine(GetTexture2D());
        }

        private IEnumerator GetTexture2D()
        {
            gameObject.SetActive(true);
            yield return new WaitForEndOfFrame();
            Texture2D newTexetTexture2D = new Texture2D(_liveRenderTexture.width, _liveRenderTexture.height);
            _camera.targetTexture = _liveRenderTexture;
            _camera.Render();
            yield return new WaitForEndOfFrame();
            RenderTexture.active = _liveRenderTexture;
            newTexetTexture2D.ReadPixels(_camera.pixelRect, 0, 0);
            Rect rectReadPicture = new Rect(0, 0, _liveRenderTexture.width, _liveRenderTexture.height);
            RenderTexture.active = _liveRenderTexture;
            newTexetTexture2D.ReadPixels(rectReadPicture, 0, 0);
            newTexetTexture2D.Apply();
            _onCompleteAction(newTexetTexture2D);

        }
    }
}

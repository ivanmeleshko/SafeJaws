﻿

using System;
using System.Collections;
using System.Collections.Generic;
using Colors;
using Enum;
using Managers;
using Model;
using Panel;
using Tools;
using UnityEngine;
using UnityEngine.UI;

namespace Screens
{
   
    public class ModelColorScreen : BaseScreen
    {
        [SerializeField] private ButtonModel[] _buttonModelButtonps;
        [SerializeField] private PanelModel[] _panelModelButtons;
        [SerializeField] private ColorModelButton[] _colorModels;
        [SerializeField] private ButtonImage[] _buttonsImage;
        [SerializeField] private Material _outputMaterial;
        [SerializeField] private Material _outputMaterialMetalic;
        [SerializeField] private ImageModel[] _images;
        [SerializeField] private Dropdown _dropDown;
        [SerializeField] private InputField _inputField;
        [SerializeField] private Slider _sliderFontSizeField;
        [SerializeField] private FontModel[] _fontModels;
        [SerializeField] private ColorPickObject _textColorPickObject;
        [SerializeField] private RenderTextScreen _renderTexturel;

        private Dictionary<PanelType, PanelModel> _panelButtonDictionaryCook;
        private Dictionary<ModelType, ButtonModel> _modelButtonDictionaryCook;
        private Dictionary<ModelType, ColorModelButton> _colorModelDictionaryCook;
        private Dictionary<ModelType, ButtonImage> _imageButtonDictionaryCook;

        private ColorObject _textColor = null;
        private Texture2D _texture2D;
        private Texture2D _texture2DTextMetalic;

        private GameManager _gameManager { get { return GameManager.Instance; } }

        protected Dictionary<ModelType, ButtonModel> ModelButtonDictionary
        {
            get
            {
                if (_modelButtonDictionaryCook == null)
                {
                    _modelButtonDictionaryCook = new Dictionary<ModelType, ButtonModel>();
                    for (int i = 0; i < _buttonModelButtonps.Length; i++)
                    {
                        if (_modelButtonDictionaryCook.ContainsKey(_buttonModelButtonps[i].ModelType))
                            throw new Exception("ButtonModel object already exist");
                        _modelButtonDictionaryCook.Add(_buttonModelButtonps[i].ModelType, _buttonModelButtonps[i]);
                    }
                }

                return _modelButtonDictionaryCook;

            }
        }

        protected Dictionary<PanelType, PanelModel> PanelButtonDictionary
        {
            get
            {
                if (_panelButtonDictionaryCook == null)
                {
                    _panelButtonDictionaryCook = new Dictionary<PanelType, PanelModel>();
                    for (int i = 0; i < _panelModelButtons.Length; i++)
                    {
                        if (_panelButtonDictionaryCook.ContainsKey(_panelModelButtons[i].PanelType))
                            throw new Exception("PanelType object already exist");
                        _panelButtonDictionaryCook.Add(_panelModelButtons[i].PanelType, _panelModelButtons[i]);
                    }
                }

                return _panelButtonDictionaryCook;

            }
        }

        protected Dictionary<ModelType, ColorModelButton> ColorModelDictionary
        {
            get
            {
                if (_colorModelDictionaryCook == null)
                {
                    _colorModelDictionaryCook = new Dictionary<ModelType, ColorModelButton>();
                    for (int i = 0; i < _colorModels.Length; i++)
                    {
                        if (_colorModelDictionaryCook.ContainsKey(_colorModels[i].ModelType))
                            throw new Exception("ColorModel object already exist");
                        _colorModelDictionaryCook.Add(_colorModels[i].ModelType, _colorModels[i]);
                    }
                }

                return _colorModelDictionaryCook;

            }
        }

        protected Dictionary<ModelType, ButtonImage> ImageButtonDictionary
        {
            get
            {
                if (_imageButtonDictionaryCook == null)
                {
                    _imageButtonDictionaryCook = new Dictionary<ModelType, ButtonImage>();
                    for (int i = 0; i < _buttonsImage.Length; i++)
                    {
                        if (_imageButtonDictionaryCook.ContainsKey(_buttonsImage[i].ModelType))
                            throw new Exception("ButtonImage object already exist");
                        _imageButtonDictionaryCook.Add(_buttonsImage[i].ModelType, _buttonsImage[i]);
                    }
                }

                return _imageButtonDictionaryCook;

            }
        }

        public override void Show(Action onComplete)
        {
            base.Show(onComplete);
            SubscribeEvents();
        }

        private void SubscribeEvents()
        {
            _panelModelButtons.ForEach<PanelModel>(p => p.SubscribeOnPanelClick(PanelSelectClick));
            _buttonModelButtonps.ForEach<ButtonModel>(p => p.SubscribeOnClick(ActivateModel));
            _colorModels.ForEach<ColorModelButton>(p=>p.Subscribe(OnClickColorModel));
            InstantiateDefaultValue();
            _texture2D = new Texture2D(2000, 2000, TextureFormat.ARGB32, false);
            _texture2DTextMetalic = new Texture2D(2000, 2000, TextureFormat.ARGB32, false);
            for (int i = 0; i < _buttonsImage.Length; i++)
                _buttonsImage[i].OnDescribeOnEvent(i, OnImageLoaded);
            SetDropDownOptions();
            _inputField.onValueChanged.AddListener(OnInputValueChange);
            _textColorPickObject.SetOnValueChangeCallback(OnValueChange);
        }

        private void InstantiateDefaultValue()
        {
            ActivateModel(ModelType.OneColor);
        }

        private void OnClickColorModel()
        {
            _colorModels.ForEach<ColorModelButton>(p => p.DeActiveteModel());
        }

        private void OnClickImage()
        {
            _colorModels.ForEach<ColorModelButton>(p => p.DeActiveteModel());
        }

        private void PanelSelectClick(PanelType panelType)
        {
            _panelModelButtons.ForEach<PanelModel>(p => p.DeactivatePanel());
            if (PanelButtonDictionary.ContainsKey(panelType))
            {
                IPanel panel = PanelButtonDictionary[panelType].ActivatePanel();
                panel.Activate(panelType);
            }
            else
                throw new Exception("PanelButtonDictionary have not panelType" + panelType.ToString());
        }

        private void ActivateModel(ModelType modelType)
        {
            if (ModelButtonDictionary.ContainsKey(modelType))
            {
                _buttonModelButtonps.ForEach<ButtonModel>(p => p.DeActiveteModel());
                ModelButtonDictionary[modelType].ActiveteModel();
                _colorModels.ForEach<ColorModelButton>(p => p.Activate(modelType));
                _gameManager.SelectJawsModel(modelType);
            }
            else
                throw new Exception("ModelButtonDictionary have not modelType"+ modelType.ToString());
        }

        private void SelectRandomColor()
        {
            _textColorPickObject.OnColorUpdateDefault();
        }

        private void OnEnable()
        {
            OnInputValueChange(string.Empty);
        }

        private void OnInputValueChange(string arg0)
        {
            if (string.IsNullOrEmpty(_inputField.text))
            {
                _textColorPickObject.Deactive();
            }
            else
            {
                _textColorPickObject.Active(ModelType.None);
                if (_textColor == null)
                    StartCoroutine(SelectDefaultColor());
            }
        }

        private IEnumerator SelectDefaultColor()
        {
            yield return new WaitForEndOfFrame();
            _textColorPickObject.OnColorUpdateDefault();
        }

        private void OnValueChange(ModelType modelType, ColorObject colorObject)
        {
            _textColor = colorObject;
            if(_firstApply)
                OnClickSetText();
        }

        private bool _firstApply = false;
        public void OnInputValueChange()
        {
        }

        public void OnClickSetText()
        {
            _firstApply = true;
            GenerateTextureByText(_inputField.text, _fontModels[_dropDown.value]);
        }

        public void OnClearText()
        {
            _inputField.text = String.Empty;
            OnClickSetText();
        }

        private void SetDropDownOptions()
        {
            _dropDown.options = new List<Dropdown.OptionData>();
            for (int i = 0; i < _fontModels.Length; i++)
            {
                var t = new Dropdown.OptionData();
                t.text = _fontModels[i].GetName();
                _dropDown.options.Add(t);
            }
        }

        private void GenerateTextureByText(string text, FontModel fontModel)
        {
            Debug.LogWarning(text);
            ScreenManager.Instance.OnShowLoadingPopup();
            fontModel.SetFontSize((int)_sliderFontSizeField.value);
            fontModel.SetFontColor(_textColor);
            _renderTexturel.OnGetTexture(text, fontModel, delegate (Texture2D d)
            {
                ScreenManager.Instance.OnHideLoadingPopup();
                _images[1].SetImageType(ImageType.TextImage);
                _images[1].UpdateTexture(d);
                CombineAllImages();
            });
        }

        public void OnImageLoaded(int index, Texture2D imageModel)
        {
            _images[index].SetImageType(ImageType.Image);
            _images[index].UpdateTexture(imageModel);
            CombineAllImages();
        }

        [ContextMenu("UpdateImages")]
        private void CombineAllImages()
        {
            ScreenManager.Instance.OnShowLoadingPopup();
            StartCoroutine(CombineAll());
        }

        public IEnumerator CombineAll()
        {
            yield return new WaitForEndOfFrame();
            yield return new WaitForEndOfFrame();
            yield return GetClearTexture(delegate { StartCoroutine(CombineTexturesAll(0)); });
        }

        public IEnumerator CombineTexturesAll(int index)
        {
            yield return new WaitForEndOfFrame();
            if (index >= _images.Length)
            {
                ScreenManager.Instance.OnHideLoadingPopup();
                _outputMaterial.mainTexture = _texture2D;
                _outputMaterialMetalic.mainTexture = _texture2DTextMetalic;
                yield break;
            }
            else
            {
                yield return new WaitForEndOfFrame();
                if (_images[index] != null &&
                    ((_images[index].ImageType == ImageType.TextImage && _textColor.MetalicSmoothess < 0.6f) ||
                     _images[index].ImageType == ImageType.Image))
                    yield return CombineTextures(_texture2D, _images[index].GetTexture(), _images[index].Offset);
                else if (_images[index] != null && _images[index].ImageType == ImageType.TextImage)
                    yield return CombineTextures(_texture2DTextMetalic, _images[index].GetTexture(), _images[index].Offset);
                yield return new WaitForEndOfFrame();
                StartCoroutine(CombineTexturesAll(++index));
            }
            yield return new WaitForEndOfFrame();
        }

        private IEnumerator GetClearTexture(Action actionComplete)
        {
            Resources.UnloadUnusedAssets();
            GC.Collect();
            yield return new WaitForEndOfFrame();
            for (int y = 0; y < _texture2D.height; y++)
            {
                for (int x = 0; x < _texture2D.width; x++)
                {
                    _texture2D.SetPixel(x, y, new Color(0, 0, 0, 0));
                }
            }
            _texture2D.Apply();
            for (int y = 0; y < _texture2DTextMetalic.height; y++)
            {
                for (int x = 0; x < _texture2DTextMetalic.width; x++)
                {
                    _texture2DTextMetalic.SetPixel(x, y, new Color(0, 0, 0, 0));
                }
            }
            _texture2DTextMetalic.Apply();
            yield return new WaitForEndOfFrame();
            actionComplete?.Invoke();
        }

        private IEnumerator CombineTextures(Texture2D currentTexture, Texture2D image, Vector3 offset)
        {
            if (image == null)
                yield break;
            else
            {
                yield return new WaitForEndOfFrame();
                for (int y = 0; y < image.height; y++)
                {
                    for (int x = 0; x < image.width; x++)
                    {
                        Color colorPixel = image.GetPixel(x, y) * image.GetPixel(x, y).a;
                        Color colorPixelBack = currentTexture.GetPixel(x + (int)offset.x, y + (int)offset.y) *
                                               (1 - colorPixel.a);
                        currentTexture.SetPixel(x + (int)offset.x, y + (int)offset.y, colorPixelBack + colorPixel);
                    }
                }

                currentTexture.Apply();
                yield return new WaitForEndOfFrame();
            }
        }
    }
}
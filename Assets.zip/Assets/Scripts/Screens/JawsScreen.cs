﻿

using System;
using Enum;

namespace Screens
{
    public class JawsScreen: BaseScreen
    {
    }
}

﻿
namespace Screens
{
    public class FinishScreen : BaseScreen
    {
        public void OnClickPrevious()
        {
            Hide();
        }
    }
}

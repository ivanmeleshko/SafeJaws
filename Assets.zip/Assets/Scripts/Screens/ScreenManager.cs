﻿
using Enum;
using Popups;
using Tools;
using UnityEngine;
using UnityEngine.Analytics;

namespace Screens
{
    public class ScreenManager : Singelton<ScreenManager>
    {
        [SerializeField] private BaseScreen _modelColorSelectScreen;
        [SerializeField] private BaseScreen _loadingScreen;
        [SerializeField] private BaseScreen _finishScreen;
        [SerializeField] private BasePopup _loadingPopup;
        [SerializeField] private BasePopup _errorPopup;

        public delegate void ScreenChangeDelegate(ScreenType screenType);
        public static ScreenChangeDelegate OnScreenChangeEvent;

        public void OnShowLoadingScreen()
        {
            _loadingScreen.Show(OnShowModelColorSelectScreen);
        }

        public void OnShowModelColorSelectScreen()
        {
            _loadingScreen.Hide();
            Debug.LogWarning("OnShowModelColorSelectScreen");
            _modelColorSelectScreen.Show(OnShowImageScreen);
            if (OnScreenChangeEvent != null) OnScreenChangeEvent(ScreenType.ModelScrenSelectSelect);
        }

        public void OnShowTextSelectScreen()
        {
            Debug.LogWarning("OnShowTextSelectScreen");
            _finishScreen.Show(null);
            if (OnScreenChangeEvent != null) OnScreenChangeEvent(ScreenType.FinishScreen);
        }

        public void OnShowImageScreen()
        {
            _modelColorSelectScreen.Hide();
            Debug.LogWarning("OnShowImageScreen");
        }

        public void OnShowLoadingPopup()
        {
            _loadingPopup.OpenPopup();
        }

        public void OnHideLoadingPopup()
        {
            _loadingPopup.ClosePopup();
        }

        public void OnShowErrorPopup(string message)
        {
            Debug.LogWarning("OnShowErrorPopup");
            _errorPopup.OpenPopup();
            (_errorPopup as WarningPopup)?.SetText(message);
        }
    }
}
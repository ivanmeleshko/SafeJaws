﻿
using UnityEngine;
using UnityEngine.EventSystems;

namespace CustomInput
{
    public class DragControlls : MonoBehaviour, IPointerExitHandler, IPointerEnterHandler, IPointerDownHandler,IPointerUpHandler
    {
        public delegate void dragDelegate(bool allow);
        public static dragDelegate OnDragAction;
        private bool _allowDrag = false;
        private bool _pointerDown = false;

        public void OnPointerExit(PointerEventData eventData)
        {
            _allowDrag = false;
            _pointerDown = false;
            OnDragAction?.Invoke(false);
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            _allowDrag = true;
            _pointerDown = true;
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            _pointerDown = true;
            if (_allowDrag && _pointerDown)
                OnDragAction?.Invoke(true);
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            OnDragAction?.Invoke(false);
        }
    }
}

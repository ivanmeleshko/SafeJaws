﻿
namespace Enum
{
    public enum SfxSounds
    {
        win,
        lose,
        enemyAppear,
        defenceSucces,
        defenceFail,
        defenceAppear,
        countdown,
        attackWinter,
        attackWhisper,
        attackSword,
        attackEagle,
        click_1,
        click_2,
        bloodEffect,
        comboEffect,
        missFailHit
    }
}

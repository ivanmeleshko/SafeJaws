﻿
namespace Enum
{
    public enum TweenType
    {
        Loop,
        PingPong,
        Once
    }
}
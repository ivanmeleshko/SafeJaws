﻿namespace Enum
{
    public enum ImageType
    {
        Image,
        TextImage,
    }
}
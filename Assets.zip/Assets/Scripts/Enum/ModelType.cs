﻿
namespace Enum
{
    public enum ModelType
    {
        None,
        OneColor,
        TwoColor,
        ThirdColor
    }
}

﻿
namespace Enum
{
    public enum PanelType
    {
        None,
        ModelSelect,
        ColorSelect,
        ImageSelect,
        TextSelect,
        PredefineSelect
    }
}

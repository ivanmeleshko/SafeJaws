﻿
namespace Enum
{
    public enum ScreenType
    {
        ModelScrenSelectSelect,
        ImageScreenSelect,
        FinishScreen
    }
}

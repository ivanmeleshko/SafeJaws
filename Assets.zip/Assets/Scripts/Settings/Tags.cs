﻿public static class Tags
{
    public static string ProfileManager = "ProfileManager";
    public static string GameManager = "GameManager";
}

﻿
using System;
using System.Collections.Generic;
using Colors;
using Enum;
using Tools;
using UnityEngine;

namespace Model
{
    public class ModelController : Singelton<ModelController>
    {
        [SerializeField] private ModelObject[] _modelObjects;

        private Dictionary<ModelType, ModelObject> _modelObjectDictionary;

        public Dictionary<ModelType, ModelObject> ModelObjectDictionary
        {
            get
            {
                if (_modelObjectDictionary == null)
                {
                    _modelObjectDictionary = new Dictionary<ModelType, ModelObject>();
                    for (int i = 0; i < _modelObjects.Length; i++)
                    {
                        if (_modelObjectDictionary.ContainsKey(_modelObjects[i].ModelType))
                        {
                            throw new Exception("Dictionary already contains this key");
                        }
                        _modelObjectDictionary.Add(_modelObjects[i].ModelType, _modelObjects[i]);
                    }
                }

                return _modelObjectDictionary;
            }
        }

        public ModelType SelectModel(ModelType modelTypeSelected)
        {
            ModelObjectDictionary.ForEach((type, p) => p.Deactive());
            if (ModelObjectDictionary.ContainsKey(modelTypeSelected))
            {
                ModelObjectDictionary[modelTypeSelected].Active();
                return modelTypeSelected;
            }

            throw new Exception("Model not find.");
        }

        public void UpdateColor(ModelType currentModel, ModelType colorType, ColorObject colorObject)
        {
            if (ModelObjectDictionary.ContainsKey(currentModel))
            {
                ModelObjectDictionary[currentModel].UpdateColor(colorType, colorObject);
            }
            else
                throw new Exception("Model not find.");
        }
    }
}
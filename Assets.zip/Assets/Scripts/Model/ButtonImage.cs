﻿
using System;
using System.Collections;
using System.Runtime.InteropServices;
using Enum;
using Model;
using Screens;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using SFB;
using Tools;

namespace Model
{
    public class ButtonImage : MonoBehaviour, IPointerDownHandler
    {
        [SerializeField] private Image _clearImage;
        [SerializeField] private ModelType _modelType;

        private int _index;
        private string _title = "";
        private string _fileName = "";
        private string _directory = "";
        private string _extension = "";
        private Action<int, Texture2D> _imageLoadEvent;

        public ModelType ModelType { get { return _modelType; } }
        
        public void ImageSelected()
        {
            _clearImage.gameObject.SetActive(true);
        }

        public void ImageDeselect()
        {
            _clearImage.gameObject.SetActive(false);
        }

        public void OnClearImage()
        {
            _imageLoadEvent?.Invoke(_index, null);
            ImageDeselect();
        }

        public void OnDescribeOnEvent(int index, Action<int, Texture2D> onDescribe)
        {
            _index = index;
            _imageLoadEvent = onDescribe;
        }

#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")]
        private static extern void UploadFile(string id);

        public void OnPointerDown(PointerEventData eventData) 
        {
            UploadFile(gameObject.name);
        }

        public void OnFileUploaded(string url) 
        {
            StartCoroutine(OutputRoutine(url));
        }
#else

        public void OnPointerDown(PointerEventData eventData)
        {

        }

        void Start()
        {
            var button = GetComponent<Button>();
            button.onClick.AddListener(OnClick);
        }

        private void OnClick()
        {
            var paths = StandaloneFileBrowser.OpenFilePanel(_title, _directory, _extension, false);
            if (paths.Length > 0)
            {
                StartCoroutine(OutputRoutine(new System.Uri(paths[0]).AbsoluteUri));
            }
        }
#endif

        private IEnumerator OutputRoutine(string url)
        {
            Debug.LogErrorFormat("URL: {0}", url);
            var loader = new WWW(url);

            ScreenManager.Instance.OnShowLoadingPopup();
            while (!loader.isDone)
                yield return new WaitForEndOfFrame();

            yield return new WaitForEndOfFrame();
            ScreenManager.Instance.OnHideLoadingPopup();
            _imageLoadEvent?.Invoke(_index, loader.texture);
            ImageSelected();
        }
    }
}

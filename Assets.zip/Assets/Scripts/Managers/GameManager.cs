﻿
using Colors;
using Enum;
using Model;
using Screens;
using Tools;

namespace Managers
{
    public class GameManager : Singelton<GameManager>
    {

        private ModelType _currentModelType = ModelType.None;
        private ModelType _currentColorModelType = ModelType.None;

        private ScreenManager _screenManager { get { return ScreenManager.Instance; } }

        public ModelType CurrentModelType { get { return _currentModelType; } }
        public ModelType CurrentColorModelType { get { return _currentColorModelType; } }

        /// <summary>
        /// Game start from here
        /// </summary>
        public void Start()
        {
            _screenManager.OnShowLoadingScreen();
        }

        public ModelType SelectJawsModel(ModelType modelType)
        {
            _currentModelType = ModelController.Instance.SelectModel(modelType);
            return _currentModelType;
        }

        public void ColorPanelClick(ModelType typeOfColor)
        {
            _currentColorModelType = typeOfColor;
        }

        public void ColorChangeClick(ModelType typeOfColor, ColorObject colorObject)
        {
            ModelController.Instance.UpdateColor(_currentModelType, typeOfColor, colorObject);
        }
    }
}
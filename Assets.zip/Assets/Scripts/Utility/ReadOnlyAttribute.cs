﻿using UnityEngine;

public class ReadOnlyAttribute : PropertyAttribute
{

}

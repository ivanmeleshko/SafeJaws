﻿using System;
using Enum;
using Model;
using Tools;
using UnityEngine;
using UnityEngine.UI;

namespace Colors
{
    public class ColorPickObject : MonoBehaviour
    {

        [SerializeField] private ModelType _modelType;
        [SerializeField] private Text _colorHelpTitle;
        [SerializeField] private ColorItem[] _colorItems;
        [SerializeField] private RectTransform _selectedRectTransform;

        private Color _color = Color.red;
        private Action<ModelType, ColorObject> _onValueChange;
        private Action<ColorItem> _onColorItemAction;

        public void DeActive(ModelType modelType)
        {
            _modelType = ModelType.None;
            gameObject.SetActive(false);
        }

        public void Active(ModelType modelType)
        {
            _modelType = modelType;
            gameObject.SetActive(true);
            _colorItems.ForEach<ColorItem>(p=>p.SubscribeOnColorChange(OnColorSelect));
        }

        public void SetPredefineColor(ColorItem colorItem)
        {
            SelectUiItem(colorItem.transform);
        }

        private void OnColorSelect(ColorItem colorItem)
        {
            _onValueChange?.Invoke(_modelType, colorItem.ColorObject);
            _onColorItemAction?.Invoke(colorItem);
            SelectUiItem(colorItem.transform);
        }

        public void Deactive()
        {
            gameObject.SetActive(false);
        }

        public void SetText(string text)
        {
            _colorHelpTitle.text = text;
        }

        public Color Color
        {
            get { return _color; }
        }

        public void SetOnValueChangeCallback(Action<ModelType, ColorObject> onValueChange)
        {
            _onValueChange = onValueChange;
        }

        public void SetOnValueChangeCallback(Action<ColorItem> onColorItemAction)
        {
            _onColorItemAction = onColorItemAction;
        }

        public void OnColorUpdateDefault()
        {
            int randomIndex = GetRandom();
            _onValueChange.Execute(_modelType, _colorItems[randomIndex].ColorObject);
            SelectUiItem(_colorItems[randomIndex].transform);
        }

        private int GetRandom()
        {
            return UnityEngine.Random.Range(0, _colorItems.Length);
        }

        private void SelectUiItem(Transform item)
        {
            _selectedRectTransform.gameObject.SetActive(true);
            LeanTween.move(_selectedRectTransform.gameObject, item, 0.002f);
        }

#if UNITY_EDITOR
        [ContextMenu("GetAllColors")]
        private void GetAllColors()
        {
            _colorItems =  new ColorItem[0];
            _colorItems = transform.GetComponentsInChildren<ColorItem>();
        }
#endif
    }
}

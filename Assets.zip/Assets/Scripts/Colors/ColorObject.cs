﻿using System;

using UnityEngine;

namespace Colors
{
    [Serializable]
    public class ColorObject
    {
        public Color Color;
        public float MetalicSmoothess = 0f;

        public ColorObject(Color color)
        {
            Color = color;
            MetalicSmoothess = 0f;
        }

        public ColorObject(Color color, float metalic)
        {
            Color = color;
            MetalicSmoothess = metalic;
        }
    }
}
